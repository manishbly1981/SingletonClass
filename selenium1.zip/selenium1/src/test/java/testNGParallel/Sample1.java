package testNGParallel;

import org.testng.annotations.Test;

public class Sample1 {
    @Test
    public void test1(){
        StaticScopeVar.driverName="Test 1 Driver";
        ThreadLocalScopeVar t1=new ThreadLocalScopeVar();
        t1.setThreadLocalVar1("Thread Local 1 Driver");
        forceWait(5);
        System.out.println(StaticScopeVar.driverName);
        System.out.println(t1.getThreadLocalVar1());
    }
    @Test
    public void test2(){
        StaticScopeVar.driverName="Test 2 Driver";
        ThreadLocalScopeVar t1=new ThreadLocalScopeVar();
        t1.setThreadLocalVar1("Thread Local 2 Driver");
        forceWait(5);
        System.out.println(StaticScopeVar.driverName);
        System.out.println(t1.getThreadLocalVar1());
    }

    public void forceWait(int timeInSec){
        try {
            System.out.println(Thread.currentThread().getId() + ": Wait start");
            Thread.sleep(timeInSec * 1000);
            System.out.println(Thread.currentThread().getId()+ ": Wait end");
        } catch (InterruptedException e) {
            System.out.println("I am inside catch");
        }
    }
}
