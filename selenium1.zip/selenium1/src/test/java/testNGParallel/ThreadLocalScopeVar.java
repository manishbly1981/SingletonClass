package testNGParallel;

public class ThreadLocalScopeVar {
    public ThreadLocal<String> threadLocalVar1= new ThreadLocal<>();

    public String getThreadLocalVar1() {
        return threadLocalVar1.get();
    }

    public void setThreadLocalVar1(String threadLocalVar1) {
        this.threadLocalVar1.set(threadLocalVar1);
    }
}
