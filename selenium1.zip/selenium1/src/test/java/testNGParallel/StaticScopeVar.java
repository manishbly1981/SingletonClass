package testNGParallel;

public class StaticScopeVar {
    public static String driverName="Default driver";
}
