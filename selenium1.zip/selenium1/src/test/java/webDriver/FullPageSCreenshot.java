package webDriver;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class FullPageSCreenshot {
     static public void main(String[] args) throws IOException {
//         WebDriver driver= new ChromeDriver();
//         WebDriver driver= new EdgeDriver();
//         driver.get("https://designmodo.com/responsive-design-examples/");
////         Screenshot myScreenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(100)).takeScreenshot(driver);
//         Screenshot myScreenshot = new AShot().shootingStrategy(ShootingStrategies.simple()).takeScreenshot(driver);
//         ImageIO.write(myScreenshot.getImage(),"PNG",new File("./elementScreenshot.png"));
//
//         driver.quit();
         WebDriver driver = new FirefoxDriver();
         driver.get("https://designmodo.com/responsive-design-examples/");
         File file= ((FirefoxDriver) driver).getFullPageScreenshotAs(OutputType.FILE);
         FileHandler.copy(file, new File("./QED_Page_Screenshot.png"));
         driver.quit();
     }
}
